
package com.huobi.jp.mgt.modulessys.entity.SysUser;

/**
* @ClassName: SysUser
* @Description:
* @author wanghe
* @date 2018-1-13
*/
public class SysUser{
	
	/**
	 *
	 */
	private Long userId;
	/**
	 *用户名
	 */
	private String username;
	/**
	 *密码
	 */
	private String password;
	/**
	 *盐
	 */
	private String salt;
	/**
	 *GA密码
	 */
	private String secret;
	/**
	 *邮箱
	 */
	private String email;
	/**
	 *手机号
	 */
	private String mobile;
	/**
	 *状态  0：禁用   1：正常
	 */
	private Integer status;
	/**
	 *部门ID
	 */
	private Long deptId;
	/**
	 *创建时间
	 */
	private Date createTime;


	public void setUserId(Long value) {
		this.userId = value;
	}

	public Long getUserId() {
		return this.userId;
	}

	public void setUsername(String value) {
		this.username = value;
	}

	public String getUsername() {
		return this.username;
	}

	public void setPassword(String value) {
		this.password = value;
	}

	public String getPassword() {
		return this.password;
	}

	public void setSalt(String value) {
		this.salt = value;
	}

	public String getSalt() {
		return this.salt;
	}

	public void setSecret(String value) {
		this.secret = value;
	}

	public String getSecret() {
		return this.secret;
	}

	public void setEmail(String value) {
		this.email = value;
	}

	public String getEmail() {
		return this.email;
	}

	public void setMobile(String value) {
		this.mobile = value;
	}

	public String getMobile() {
		return this.mobile;
	}

	public void setStatus(Integer value) {
		this.status = value;
	}

	public Integer getStatus() {
		return this.status;
	}

	public void setDeptId(Long value) {
		this.deptId = value;
	}

	public Long getDeptId() {
		return this.deptId;
	}

	public void setCreateTime(Date value) {
		this.createTime = value;
	}

	public Date getCreateTime() {
		return this.createTime;
	}
}

