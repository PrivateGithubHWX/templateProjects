package com.huobi.jp.mgt.modulessys.dao.SysUser;

import com.huobi.jp.mgt.modulessys.entity.SysUser;

/**
* @ClassName: SysUserMapper
* @Description:
* @author wanghe
* @date 2018-1-13
*/
public interface SysUserMapper{

     public int save (SysUser  sysUser);

     public SysUser selectById (SysUser  sysUser);

     public int updateByIdSelective(SysUser sysUser);

     public int updateById(SysUser sysUser);

     public int deleteById(SysUser sysUser);

}