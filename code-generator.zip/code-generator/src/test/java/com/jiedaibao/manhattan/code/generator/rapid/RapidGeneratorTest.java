package com.jiedaibao.manhattan.code.generator.rapid;

import com.jiedaibao.manhattan.code.generator.rapid.model.DBConfig;

/**
 * Created by Administrator on 2017/11/8.
 */
public class RapidGeneratorTest {

    /**
     * @throws Exception
     */

    public void testGeneratorOneTable(String tableName) throws Exception {
        RapidGenerator rapidGenerator = new RapidGenerator();
        rapidGenerator.setAuthor("wanghe");

        DBConfig dbConfig = new DBConfig();
        dbConfig.setUrl("jdbc:mysql://10.111.3.223:3306/jpmgt");
        dbConfig.setUserName("newbi");
        dbConfig.setPwd("newBiv5");
        dbConfig.setDriver("com.mysql.jdbc.Driver");
        dbConfig.setSchema("");
        dbConfig.setCatalog("");

        rapidGenerator.initDbConfig(dbConfig);
        //输出路径
        rapidGenerator
            .initOutRootPathConfig("/Users/wanghe/mybatisCode");
        String path="com.huobi.jp.mgt.modules";
        //模块名
        String model="sys";
        //项目名
        rapidGenerator.initPackage(path+"."+model);


        //表名
        rapidGenerator.generatorOneTable(tableName);

    }

    public static void main(String[] args) throws Exception {
        RapidGeneratorTest rapidGeneratorTest;
        args = new String[] { "sys_user"};
        for (int i = 0; i < args.length; i++) {
            rapidGeneratorTest = new RapidGeneratorTest();
            rapidGeneratorTest.testGeneratorOneTable(args[i]);
        }
    }
}
