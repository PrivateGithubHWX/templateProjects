package com.huobi.jp.mgt.mybatis.generator;

import org.apache.commons.io.FileUtils;
import org.apache.commons.lang.StringUtils;
import org.mybatis.generator.api.MyBatisGenerator;
import org.mybatis.generator.api.ProgressCallback;
import org.mybatis.generator.config.CommentGeneratorConfiguration;
import org.mybatis.generator.config.Configuration;
import org.mybatis.generator.config.Context;
import org.mybatis.generator.config.xml.ConfigurationParser;
import org.mybatis.generator.internal.DefaultShellCallback;

import java.io.File;
import java.io.IOException;
import java.text.MessageFormat;
import java.util.ArrayList;
import java.util.List;

/**
 * Created by GuoLiang on 2016-11-02 10:14.
 */
public class MyBatisGeneratorUtils {

    public static void main(String[] args) {
        try {
//            File daoDirectory = new File("src/main/java/com/huobi/auth/dao");
//            File entity = new File("src/main/java/com/huobi/auth/model/entity");
//            File mapper = new File("src/main/resources/mapper");
//            deleteFiles(daoDirectory);
//            deleteFiles(entity);
//            deleteFiles(mapper);

            List<String> warnings = new ArrayList<>();
            File configFile = new File("src/main/java/com/huobi/jp/mgt/mybatis/generator/generatorConfig.xml");
            ConfigurationParser cp = new ConfigurationParser(warnings);
            Configuration config = cp.parseConfiguration(configFile);
            DefaultShellCallback callback = new DefaultShellCallback(true);
            MyBatisGenerator myBatisGenerator = new MyBatisGenerator(config, callback, warnings);
//            Context mysqlContext = config.getContext("Mysql");
//            CommentGeneratorConfiguration commentGeneratorConfiguration = new CommentGeneratorConfiguration();
//            commentGeneratorConfiguration.getProperties().setProperty("suppressDate", "true");
//            mysqlContext.setCommentGeneratorConfiguration(commentGeneratorConfiguration);
            myBatisGenerator.generate(new MyProcessCallback());

            for (String warning : warnings) {
                System.out.println("警告: " + warning);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private static void deleteFiles(File dir) throws IOException {
        File[] files = dir.listFiles((dir1, name) -> {
            if (StringUtils.contains(name, "impl") || StringUtils.contains(name, "complex")) {
                return false;
            }
            return StringUtils.endsWith(name, ".java") || StringUtils.endsWith(name, ".xml") || dir1.isDirectory();
        });
        if (files != null) {
            for (File file : files) {
                FileUtils.forceDelete(file);
            }
        }
    }

    private static class MyProcessCallback implements ProgressCallback {
        @Override
        public void introspectionStarted(int totalTasks) {
            System.out.println(MessageFormat.format("分析开始,总任务数为: [{0}]", totalTasks));
        }

        @Override
        public void generationStarted(int totalTasks) {
            System.out.println(MessageFormat.format("开始生成,总任务数为: [{0}]", totalTasks));
        }

        @Override
        public void saveStarted(int totalTasks) {
            System.out.println(MessageFormat.format("任务总数: [{0}]", totalTasks));
        }

        @Override
        public void startTask(String taskName) {
            System.out.println(MessageFormat.format("正在执行任务: [{0}]", taskName));
        }

        @Override
        public void done() {
            System.out.println("生成结束!");
        }

        @Override
        public void checkCancel() throws InterruptedException {
//            System.out.println("检查是否取消!");
        }
    }
}
