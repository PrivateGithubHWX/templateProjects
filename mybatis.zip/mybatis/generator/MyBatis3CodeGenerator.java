package com.huobi.jp.mgt.mybatis.generator;

import org.apache.commons.lang.StringUtils;
import org.mybatis.generator.codegen.mybatis3.IntrospectedTableMyBatis3Impl;

import static org.mybatis.generator.internal.util.StringUtility.stringHasValue;

/**
 * Created by GuoLiang on 2016-11-02 16:21.
 */
public class MyBatis3CodeGenerator extends IntrospectedTableMyBatis3Impl {

    /**
     * Calculate java client attributes.
     */
    protected void calculateJavaClientAttributes() {
        if (context.getJavaClientGeneratorConfiguration() == null) {
            return;
        }
        String domainObjectName = fullyQualifiedTable.getDomainObjectName();
        String module = this.getTableConfigurationProperty("removePrefix");
        if (null != module) {
            domainObjectName = domainObjectName.replaceFirst(module, "");
        }

        StringBuilder sb = new StringBuilder();
        sb.append(calculateJavaClientImplementationPackage());
        sb.append('.');
        sb.append(domainObjectName);
        sb.append("DAOImpl"); //$NON-NLS-1$
        setDAOImplementationType(sb.toString());

        sb.setLength(0);
        sb.append(calculateJavaClientInterfacePackage());
        sb.append('.');
        sb.append(domainObjectName);
        sb.append("DAO"); //$NON-NLS-1$
        setDAOInterfaceType(sb.toString());

        sb.setLength(0);
        sb.append(calculateJavaClientInterfacePackage());
        sb.append('.');
        if (stringHasValue(tableConfiguration.getMapperName())) {
            sb.append(tableConfiguration.getMapperName());
        } else {
            sb.append(domainObjectName);
            sb.append("Mapper"); //$NON-NLS-1$
        }
        setMyBatis3JavaMapperType(sb.toString());

        sb.setLength(0);
        sb.append(calculateJavaClientInterfacePackage());
        sb.append('.');
        if (stringHasValue(tableConfiguration.getSqlProviderName())) {
            sb.append(tableConfiguration.getSqlProviderName());
        } else {
            sb.append(domainObjectName);
            sb.append("SqlProvider"); //$NON-NLS-1$
        }
        setMyBatis3SqlProviderType(sb.toString());
    }


    protected void calculateModelAttributes() {
        String domainObjectName = fullyQualifiedTable.getDomainObjectName();
        String module = this.getTableConfigurationProperty("removePrefix");
        if (null != module) {
            domainObjectName = domainObjectName.replaceFirst(module, "");
        }

        String pakkage = calculateJavaModelPackage();
        StringBuilder sb = new StringBuilder();
        sb.append(pakkage);
        sb.append('.');
        sb.append(domainObjectName);
        sb.append("Key"); //$NON-NLS-1$
        setPrimaryKeyType(sb.toString());

        sb.setLength(0);
        sb.append(pakkage);
        sb.append('.');
        sb.append(domainObjectName);
        setBaseRecordType(sb.toString());

        sb.setLength(0);
        sb.append(pakkage);
        sb.append('.');
        sb.append(domainObjectName);
        sb.append("WithBLOBs"); //$NON-NLS-1$
        setRecordWithBLOBsType(sb.toString());

        sb.setLength(0);
        sb.append(pakkage);
        sb.append('.');
        sb.append(domainObjectName);
        sb.append("Example"); //$NON-NLS-1$
        setExampleType(sb.toString());
    }

    @Override
    protected String calculateMyBatis3XmlMapperFileName() {
        String fileName = super.calculateMyBatis3XmlMapperFileName();
        String module = this.getTableConfigurationProperty("removePrefix");
        fileName = fileName.replaceFirst(module, "");
        return fileName;
    }
}
