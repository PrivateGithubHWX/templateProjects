package com.huobi.jp.mgt.mybatis.generator;

import org.apache.ibatis.annotations.Mapper;
import org.mybatis.generator.api.IntrospectedTable;
import org.mybatis.generator.api.PluginAdapter;
import org.mybatis.generator.api.dom.java.FullyQualifiedJavaType;
import org.mybatis.generator.api.dom.java.Interface;
import org.mybatis.generator.api.dom.java.TopLevelClass;

import java.util.List;

/**
 * Created by GuoLiang on 2016-11-02 11:58.
 */

@Mapper
public class MBGRepositoryPlugin extends PluginAdapter {

    @Override
    public boolean validate(List<String> warnings) {
        return true;
    }

    @Override
    public void initialized(IntrospectedTable introspectedTable) {
        System.out.println("introspectedTable = " + introspectedTable);
        introspectedTable.getTableConfiguration().setDomainObjectName("AAA");
    }

    @Override
    public boolean modelExampleClassGenerated(TopLevelClass topLevelClass, IntrospectedTable introspectedTable) {
        topLevelClass.addImportedType("org.apache.ibatis.annotations.Mapper");
        topLevelClass.addAnnotation("@Mapper");
        return super.modelExampleClassGenerated(topLevelClass, introspectedTable);
    }

    @Override
    public boolean clientGenerated(Interface interfaze, TopLevelClass topLevelClass, IntrospectedTable introspectedTable) {
        System.out.println("interfaze = [" + interfaze + "], topLevelClass = [" + topLevelClass + "], introspectedTable = [" + introspectedTable + "]");
        interfaze.addImportedType(new FullyQualifiedJavaType("org.apache.ibatis.annotations.Mapper"));
        interfaze.addAnnotation("@Mapper");
        return super.clientGenerated(interfaze, topLevelClass, introspectedTable);
    }
}
