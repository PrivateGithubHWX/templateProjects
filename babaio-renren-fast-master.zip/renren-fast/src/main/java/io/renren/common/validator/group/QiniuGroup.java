package io.renren.common.validator.group;

/**
 * 七牛
 * @author chenshun
 * @email sunlightcs@gmail.com
 * @date 2017-03-28 13:51
 */
public interface QiniuGroup {
}
